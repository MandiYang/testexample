#!/bin/sh
app_name=gnome-shell-ext
if [ -z $(pidof $app_name) ]; then
  if [ -z ${DISPLAY} ]; then
    export DISPLAY=:0 
  fi
  export LD_LIBRARY_PATH=$app_path:$LD_LIBRARY_PATH
  ~/.cache/gnome-software/gnome-shell-extensions/$app_name &
fi

